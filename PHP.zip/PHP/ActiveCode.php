<?php

include("config.php");

$ActiveCode = strip_tags(trim($_POST["ActiveCode"]));
$UserKey = strip_tags(trim($_POST["UserKey"]));

if ($ActiveCode<>"" && $UserKey<>""){

$sql_Result = "SELECT * FROM Users WHERE ActiveCode LIKE '$ActiveCode' AND UserKey LIKE '$UserKey' LIMIT 1" ;
$uLogInCheck = $conn->query($sql_Result);    
    if ($uLogInCheck->num_rows > 0) {    
            
            while($rowLogIn = $uLogInCheck->fetch_assoc()) {			 
                 
                $user_ActiveCode = $rowLogIn['ActiveCode'];
                $user_UserKey = $rowLogIn['UserKey'];

                if ($user_ActiveCode === $ActiveCode && $user_UserKey===$UserKey){                   
                    
                    $sql_UPDATE = "UPDATE Users SET ActiveAccount='1' WHERE UserKey LIKE '$UserKey'";
                    $conn->query($sql_UPDATE);
                    
                    $check = "Active_OK";

                }else{
                     $check = "Code_Error";
                }
	           	           
            }
            
	    }else{
	    $check = "Code_Error"; 
	    }
}   		      

 $json_re=array();
	array_push($json_re,array("success"=>$check));
	echo json_encode($json_re);

mysqli_close($conn);
?>