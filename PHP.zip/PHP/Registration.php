<?php

include("config.php");

date_default_timezone_set("Asia/Muscat");
$RegDate= date("Y/m/d - h:i a");


$UserName = strip_tags(trim($_POST["UserName"]));
$Password = strip_tags(trim($_POST["Password"]));
$Email = strip_tags(trim($_POST["Email"]));
$ImgCode_Avatar= strip_tags(trim($_POST["ImgCode_Avatar"]));

$DeviceID= strip_tags(trim($_POST["DeviceID"]));

if ($UserName<>"" && $Password<>"" && $Email<>""){


$sql_UserType = "SELECT * FROM Users WHERE UserType LIKE '%Block%' AND DeviceID LIKE '$DeviceID' ";	
	$UserTypeCheck = $conn->query($sql_UserType);    
    if ($UserTypeCheck->num_rows > 0) { 
		$check = "UserBlock";
	}else{


		//حفظ الصورة
		$dateeCode=date("Ymdhi");
		$randomletter = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, 5);
		$milliseconds = round(microtime(true));
		$UserKey = "U".$randomletter.$dateeCode.$milliseconds;
		$ActiveCode = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, 5);
		$Avatar = $UserKey.".jpg";
		if ($ImgCode_Avatar<>"") {   					
				$decodimg = base64_decode("$ImgCode_Avatar");
				file_put_contents("Images/".$Avatar,$decodimg);
			}


		//تسجيل عضو جديد
		$newPass = md5($Password);
		$sql_query = "INSERT INTO Users (UserKey, UserName, Password, Email, RegDate, Avatar, ActiveCode, UserType, DeviceID)VALUES('$UserKey','$UserName','$newPass','$Email','$RegDate','$Avatar','$ActiveCode','User','$DeviceID')";
			$dbResult = $conn->query($sql_query);
			if ($dbResult === TRUE) {

		$check = "Reg_OK"; 

		//إرسال كود التفعيل إلى ملف PHP_Mailer
		
		$data = array("Email"=>$Email,"Avatar"=>$Avatar,"Active_Code"=>$ActiveCode,"UserName"=>$UserName);
		$fields_string = http_build_query($data);

		//open connection
		$ch = curl_init();
		
		$UrlPost = "https://novbook.net/test/android/PHPMailer/PHPMailer_Send_ActiveCode.php";
		curl_setopt($ch,CURLOPT_URL, $UrlPost);
		curl_setopt($ch,CURLOPT_POST, count($data));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch,CURLOPT_FORBID_REUSE, 1);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
		
		//execute post
		$result = curl_exec($ch);		
		curl_close($ch);
		

		} else {
		 $check = "Error"; 
		}


	}
}





$json_re=array();
array_push($json_re,array("success"=>$check, "UserKey"=>$UserKey));
echo json_encode($json_re);

mysqli_close($conn);

?>
